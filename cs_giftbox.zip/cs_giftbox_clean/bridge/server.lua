Bridge = {}

local framework = 'standalone'
local QBCore
local ESX

local function isStarted(resource)
    return GetResourceState(resource) == 'started'
end

local function normalizeGender(value)
    if value == nil then
        return nil
    end

    if value == 0 or value == '0' then
        return 'male'
    end

    if value == 1 or value == '1' then
        return 'female'
    end

    value = tostring(value):lower()

    if value == 'm' or value == 'male' then
        return 'male'
    end

    if value == 'f' or value == 'female' then
        return 'female'
    end

    return nil
end

local function detectFramework()
    local requested = tostring(Config.Framework or 'auto'):lower()

    if requested ~= 'auto' then
        return requested
    end

    if isStarted('qbx_core') then
        return 'qbox'
    end

    if isStarted('qb-core') then
        return 'qbcore'
    end

    if isStarted('es_extended') then
        return 'esx'
    end

    return 'standalone'
end

CreateThread(function()
    framework = detectFramework()

    if framework == 'qbcore' then
        QBCore = exports['qb-core']:GetCoreObject()
    elseif framework == 'esx' then
        ESX = exports.es_extended:getSharedObject()
    end

    print(('[cs_giftbox] Framework detected: %s'):format(framework))
end)

function Bridge.GetFramework()
    return framework
end

function Bridge.GetPlayer(source)
    if framework == 'qbox' then
        return exports.qbx_core:GetPlayer(source)
    end

    if framework == 'qbcore' then
        return QBCore and QBCore.Functions.GetPlayer(source)
    end

    if framework == 'esx' then
        return ESX and ESX.GetPlayerFromId(source)
    end

    return GetPlayerName(source) and { source = source } or nil
end

function Bridge.GetIdentifier(source)
    local player = Bridge.GetPlayer(source)

    if not player then
        return 'unknown'
    end

    if framework == 'qbox' or framework == 'qbcore' then
        return player.PlayerData
            and player.PlayerData.citizenid
            or 'unknown'
    end

    if framework == 'esx' then
        return player.identifier
            or (player.getIdentifier and player.getIdentifier())
            or 'unknown'
    end

    return GetPlayerIdentifierByType(source, 'license')
        or GetPlayerIdentifier(source, 0)
        or 'unknown'
end

function Bridge.GetGender(source)
    local player = Bridge.GetPlayer(source)

    if not player then
        return nil
    end

    if framework == 'qbox' or framework == 'qbcore' then
        local charinfo = player.PlayerData and player.PlayerData.charinfo
        return normalizeGender(charinfo and charinfo.gender)
    end

    if framework == 'esx' then
        local sex

        if player.get then
            sex = player.get('sex')
        end

        if sex == nil and player.variables then
            sex = player.variables.sex
        end

        return normalizeGender(sex)
    end

    return nil
end

function Bridge.AddMoney(source, account, amount)
    amount = tonumber(amount)

    if not amount or amount <= 0 then
        return false
    end

    account = account or 'cash'

    if framework == 'qbox' then
        return exports.qbx_core:AddMoney(
            source,
            account,
            amount,
            'gift-box-reward'
        ) == true
    end

    if framework == 'qbcore' then
        local player = Bridge.GetPlayer(source)

        if not player then
            return false
        end

        return player.Functions.AddMoney(
            account,
            amount,
            'gift-box-reward'
        ) == true
    end

    if framework == 'esx' then
        local player = Bridge.GetPlayer(source)

        if not player then
            return false
        end

        if account == 'cash' or account == 'money' then
            player.addMoney(amount, 'gift-box-reward')
            return true
        end

        player.addAccountMoney(account, amount, 'gift-box-reward')
        return true
    end

    local moneyItem = account == 'bank' and 'bank_money' or 'money'

    if not exports.ox_inventory:CanCarryItem(source, moneyItem, amount) then
        return false
    end

    local success = exports.ox_inventory:AddItem(source, moneyItem, amount)
    return success == true
end
