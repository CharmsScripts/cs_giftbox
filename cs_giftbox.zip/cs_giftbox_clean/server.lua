local ox_inventory = exports.ox_inventory

local cooldowns = {}
local opening = {}

local function debugPrint(message)
    if Config.Debug then
        print(('[cs_giftbox] %s'):format(message))
    end
end

local function notify(source, notificationType, description)
    TriggerClientEvent('ox_lib:notify', source, {
        title = Config.NotifyTitle,
        type = notificationType,
        description = description
    })
end

local function rewardLabel(reward)
    if reward.label then
        return reward.label
    end

    if reward.type == 'item' and reward.item then
        local item = ox_inventory:Items(reward.item)
        return item and item.label or reward.item
    end

    return 'Reward'
end

local function canCarryAllRewards(source, rewards)
    for i = 1, #rewards do
        local reward = rewards[i]

        if reward.type == 'item' then
            local canCarry = ox_inventory:CanCarryItem(
                source,
                reward.item,
                reward.amount,
                reward.metadata
            )

            if not canCarry then
                return false, rewardLabel(reward)
            end
        end
    end

    return true
end

local function giveReward(source, reward)
    if reward.type == 'money' then
        return Bridge.AddMoney(
            source,
            reward.account or 'cash',
            reward.amount
        )
    end

    if reward.type == 'item' then
        local success, response = ox_inventory:AddItem(
            source,
            reward.item,
            reward.amount,
            reward.metadata
        )

        if not success then
            debugPrint(
                ('Failed to add %sx %s: %s'):format(
                    reward.amount,
                    tostring(reward.item),
                    tostring(response)
                )
            )
        end

        return success == true
    end

    return false
end

local function formatReward(reward)
    if reward.type == 'money' then
        return ('$%s %s'):format(
            reward.amount,
            rewardLabel(reward)
        )
    end

    return ('%sx %s'):format(
        reward.amount,
        rewardLabel(reward)
    )
end

local function refundBox(source, boxItem, metadata)
    local success, response = ox_inventory:AddItem(
        source,
        boxItem,
        1,
        metadata
    )

    if not success then
        print(
            ('[cs_giftbox] Could not refund %s to player %s: %s'):format(
                boxItem,
                source,
                tostring(response)
            )
        )
    end
end

exports('openGiftBox', function(event, item, inventory, slot, data)
    if event ~= 'usingItem' then
        return
    end

    local source = inventory and tonumber(inventory.id)

    if not source or source <= 0 then
        return false
    end

    if not Bridge.GetPlayer(source) then
        return false
    end

    if opening[source] then
        notify(source, 'error', 'You are already opening a gift box.')
        return false
    end

    local now = os.time()
    local lastOpened = cooldowns[source] or 0

    if now - lastOpened < Config.CooldownSeconds then
        notify(source, 'error', 'Please wait before opening another gift box.')
        return false
    end

    local boxItem = item and item.name
    local box = boxItem and Config.Boxes[boxItem]

    if not box then
        notify(source, 'error', 'This gift box is not configured.')
        return false
    end

    if Config.EnforceGender and box.requiredGender then
        local gender = Bridge.GetGender(source)

        if not gender and Config.BlockUnknownGender then
            notify(source, 'error', 'Your character gender could not be detected.')
            return false
        end

        if gender and gender ~= box.requiredGender then
            notify(
                source,
                'error',
                ('This box is only for %s characters.'):format(
                    box.requiredGender
                )
            )
            return false
        end
    end

    local slotData = ox_inventory:GetSlot(inventory.id, slot)

    if not slotData or slotData.name ~= boxItem or slotData.count < 1 then
        notify(source, 'error', 'The gift box could not be found.')
        return false
    end

    local canCarry, failedReward = canCarryAllRewards(
        source,
        box.rewards
    )

    if not canCarry then
        notify(
            source,
            'error',
            ('You need more inventory space for %s.'):format(
                failedReward
            )
        )
        return false
    end

    opening[source] = true

    local removed, removeResponse = ox_inventory:RemoveItem(
        inventory.id,
        boxItem,
        1,
        slotData.metadata,
        slot
    )

    if not removed then
        opening[source] = nil
        debugPrint(('RemoveItem failed: %s'):format(tostring(removeResponse)))
        notify(source, 'error', 'The gift box could not be opened.')
        return false
    end

    local received = {}

    for i = 1, #box.rewards do
        local reward = box.rewards[i]

        if not giveReward(source, reward) then
            refundBox(source, boxItem, slotData.metadata)
            opening[source] = nil

            notify(
                source,
                'error',
                ('%s could not be given. Your gift box was returned.'):format(
                    rewardLabel(reward)
                )
            )

            return false
        end

        received[#received + 1] = formatReward(reward)
    end

    cooldowns[source] = now
    opening[source] = nil

    notify(
        source,
        'success',
        ('You received: %s'):format(
            table.concat(received, ', ')
        )
    )

    print(
        ('[cs_giftbox] %s [%s] opened %s and received %s'):format(
            GetPlayerName(source) or 'Unknown',
            Bridge.GetIdentifier(source),
            boxItem,
            table.concat(received, ', ')
        )
    )

    return false
end)

AddEventHandler('playerDropped', function()
    cooldowns[source] = nil
    opening[source] = nil
end)
