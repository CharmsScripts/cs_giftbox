-- Add these inside ox_inventory/data/items.lua

['giftbox_female'] = {
    label = 'Female Gift Box',
    weight = 500,
    stack = true,
    close = true,
    consume = 0,
    description = 'Contains a female starter package.',
    server = {
        export = 'cs_giftbox.openGiftBox'
    }
},

['giftbox_male'] = {
    label = 'Male Gift Box',
    weight = 500,
    stack = true,
    close = true,
    consume = 0,
    description = 'Contains a male starter package.',
    server = {
        export = 'cs_giftbox.openGiftBox'
    }
},

-- Only add these if your server does not already have them.

['vehicle_voucher'] = {
    label = 'Vehicle Voucher',
    weight = 0,
    stack = true,
    close = true,
    description = 'Redeem this voucher for an eligible vehicle.'
},

['wheelspin'] = {
    label = 'Wheel Spin',
    weight = 0,
    stack = true,
    close = true,
    description = 'Redeem this for one wheel spin.'
},
