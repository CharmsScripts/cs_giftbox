Config = {}

-- auto, qbox, qbcore, esx, standalone
Config.Framework = 'auto'

Config.NotifyTitle = 'Gift Box'
Config.CooldownSeconds = 3
Config.EnforceGender = true
Config.BlockUnknownGender = true
Config.Debug = false

-- Change these names if your server uses different item names.
Config.Items = {
    FemaleBox = 'giftbox_female',
    MaleBox = 'giftbox_male',
    Pistol = 'WEAPON_PISTOL',
    PistolAmmo = 'ammo-9',
    VehicleVoucher = 'vehicle_voucher',
    WheelSpin = 'wheelspin'
}

Config.Boxes = {
    giftbox_female = {
        label = 'Female Gift Box',
        requiredGender = 'female',

        rewards = {
            {
                type = 'money',
                account = 'cash',
                label = 'Cash',
                amount = 10000
            },
            {
                type = 'item',
                item = 'WEAPON_PISTOL',
                label = 'Pistol',
                amount = 1,
                metadata = {
                    registered = false
                }
            },
            {
                type = 'item',
                item = 'ammo-9',
                label = 'Pistol Ammo',
                amount = 30
            },
            {
                type = 'item',
                item = 'vehicle_voucher',
                label = 'Vehicle Voucher',
                amount = 1
            }
        }
    },

    giftbox_male = {
        label = 'Male Gift Box',
        requiredGender = 'male',

        rewards = {
            {
                type = 'money',
                account = 'cash',
                label = 'Cash',
                amount = 10000
            },
            {
                type = 'item',
                item = 'WEAPON_PISTOL',
                label = 'Pistol',
                amount = 1,
                metadata = {
                    registered = false
                }
            },
            {
                type = 'item',
                item = 'ammo-9',
                label = 'Pistol Ammo',
                amount = 30
            },
            {
                type = 'item',
                item = 'wheelspin',
                label = 'Wheel Spin',
                amount = 1
            }
        }
    }
}
