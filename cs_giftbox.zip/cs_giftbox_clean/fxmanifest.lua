fx_version 'cerulean'
game 'gta5'

author 'Charms Scripts'
description 'Male and Female Starter Gift Boxes'
version '1.0.0'

lua54 'yes'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

server_scripts {
    'bridge/server.lua',
    'server.lua'
}

dependencies {
    'ox_lib',
    'ox_inventory'
}
